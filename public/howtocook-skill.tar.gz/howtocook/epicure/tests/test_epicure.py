"""Tests for epicure.engine — ingredient intelligence module."""

import sys

sys.path.insert(0, "/Users/dor/Projects/HowToCook_Plan/howtocook-skill")

import pytest

from epicure.engine import (
    ModeResult,
    PairingResult,
    get_cuisine_poles,
    get_mode,
    get_pairings,
    get_substitute,
    list_vocab,
    search_ingredient,
    slerp_explore,
)


# ---------------------------------------------------------------------------
# 1. get_pairings
# ---------------------------------------------------------------------------


def test_get_pairings():
    results = get_pairings("chicken", 5)
    assert len(results) == 5
    assert results[0].score > 0.5
    for r in results:
        assert isinstance(r, PairingResult)
        assert hasattr(r, "name")
        assert hasattr(r, "name_zh")
        assert hasattr(r, "score")


# ---------------------------------------------------------------------------
# 2. get_pairings excludes self
# ---------------------------------------------------------------------------


def test_get_pairings_excludes_self():
    results = get_pairings("chicken")
    names = [r.name for r in results]
    assert "chicken" not in names


# ---------------------------------------------------------------------------
# 3. get_substitute
# ---------------------------------------------------------------------------


def test_get_substitute():
    results = get_substitute("butter", 3)
    assert len(results) == 3
    for r in results:
        assert 0.0 <= r.score <= 1.0


# ---------------------------------------------------------------------------
# 4. slerp_explore — South_Asian direction
# ---------------------------------------------------------------------------


def test_slerp_cuisine_direction():
    results = slerp_explore("rice", "South_Asian", 60, 5)
    names = {r.name for r in results}
    south_asian_spices = {"mustard_seed", "turmeric", "fenugreek"}
    assert names & south_asian_spices, (
        f"Expected at least one South Asian spice in {names}"
    )


# ---------------------------------------------------------------------------
# 5. slerp_explore — angle zero
# ---------------------------------------------------------------------------


def test_slerp_angle_zero():
    results_slerp = slerp_explore("chicken", "South_Asian", 0, 5)
    results_pairing = get_pairings("chicken", 5)
    slerp_names = [r.name for r in results_slerp]
    pairing_names = [r.name for r in results_pairing]
    assert slerp_names == pairing_names


# ---------------------------------------------------------------------------
# 6. slerp_explore — invalid direction raises ValueError
# ---------------------------------------------------------------------------


def test_slerp_invalid_direction():
    with pytest.raises(ValueError, match="nonexistent_cuisine"):
        slerp_explore("chicken", "nonexistent_cuisine", 30)


# ---------------------------------------------------------------------------
# 7. get_mode
# ---------------------------------------------------------------------------


def test_get_mode():
    results = get_mode("chicken", 2)
    assert len(results) == 2
    for r in results:
        assert isinstance(r, ModeResult)
        assert r.label  # non-empty label


# ---------------------------------------------------------------------------
# 8. search_ingredient — English prefix
# ---------------------------------------------------------------------------


def test_search_english_prefix():
    results = search_ingredient("chi", 5)
    assert len(results) <= 5
    assert len(results) > 0
    for name in results:
        assert name.startswith("chi")


# ---------------------------------------------------------------------------
# 9. search_ingredient — Chinese reverse lookup
# ---------------------------------------------------------------------------


def test_search_chinese():
    results = search_ingredient("鸡肉")
    assert "chicken" in results


# ---------------------------------------------------------------------------
# 10. get_cuisine_poles
# ---------------------------------------------------------------------------


def test_get_cuisine_poles():
    poles = get_cuisine_poles()
    assert isinstance(poles, dict)
    assert len(poles) >= 5


# ---------------------------------------------------------------------------
# 11. list_vocab
# ---------------------------------------------------------------------------


def test_list_vocab():
    vocab = list_vocab()
    assert len(vocab) == 1790


# ---------------------------------------------------------------------------
# 12. zh_name mapping
# ---------------------------------------------------------------------------


def test_zh_name_mapping():
    results_pork = get_pairings("pork", 1)
    # pork itself is excluded, but we can verify the zh_map via search
    found_pork = search_ingredient("猪肉")
    assert "pork" in found_pork

    found_chicken = search_ingredient("鸡肉")
    assert "chicken" in found_chicken
