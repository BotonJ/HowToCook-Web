"""Epicure ingredient intelligence — core computation engine.

Pure Python. Zero external dependencies (no numpy/scipy/pandas).
Uses only stdlib: json, math, dataclasses, pathlib.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Module-level lazy cache
# ---------------------------------------------------------------------------

_embeddings: Optional[list[list[float]]] = None
_metadata: Optional[dict] = None
_vocab: Optional[dict[str, int]] = None
_itos: Optional[list[str]] = None
_norms: Optional[list[float]] = None
_zh_map: Optional[dict[str, str]] = None

_DATA_DIR = Path(__file__).parent / "data"


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class PairingResult:
    """A single pairing / substitution candidate."""

    name: str       # English canonical name
    name_zh: str    # Chinese name (from zh_map, empty if unknown)
    score: float    # cosine similarity [0, 1]


@dataclass
class ModeResult:
    """A mode cluster result."""

    mode_id: str
    kind: str           # "factor" | "continuous" | "binary"
    property: str
    label: str
    score: float        # cosine to mode centroid
    n_members: int
    members: list[str]  # top-20 members


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _ensure_loaded() -> None:
    """Lazy-load data files on first call. Module-level cache."""
    global _embeddings, _metadata, _vocab, _itos, _norms, _zh_map
    if _embeddings is not None:
        return

    with open(_DATA_DIR / "metadata.json", encoding="utf-8") as f:
        _metadata = json.load(f)
    _vocab = _metadata["vocab"]
    _itos = _metadata["itos"]

    with open(_DATA_DIR / "embeddings.json", encoding="utf-8") as f:
        _embeddings = json.load(f)

    # Precompute L2 norms
    _norms = [_vec_norm(v) for v in _embeddings]

    with open(_DATA_DIR / "epicure_vocab_zh.json", encoding="utf-8") as f:
        _zh_map = json.load(f)


def _vec_norm(v: list[float]) -> float:
    """L2 norm of a vector."""
    return math.sqrt(sum(x * x for x in v))


def _dot(a: list[float], b: list[float]) -> float:
    """Dot product of two vectors."""
    return sum(ai * bi for ai, bi in zip(a, b))

_NORM_EPS = 1e-10


def _cosine_sim(a: list[float], b: list[float],
                norm_a: float | None = None,
                norm_b: float | None = None) -> float:
    """Cosine similarity between two vectors."""
    na = norm_a if norm_a is not None else _vec_norm(a)
    nb = norm_b if norm_b is not None else _vec_norm(b)
    denom = na * nb
    if denom < _NORM_EPS:
        return 0.0
    return _dot(a, b) / denom


def _normalize_vec(v: list[float]) -> list[float]:
    """Return unit vector."""
    n = _vec_norm(v)
    if n < _NORM_EPS:
        return v
    return [x / n for x in v]


def _get_embedding(name: str) -> list[float]:
    """Get embedding for an ingredient name. Raises KeyError if not found."""
    _ensure_loaded()
    idx = _vocab[name]  # type: ignore[index]
    return _embeddings[idx]  # type: ignore[index]


def _get_norm(idx: int) -> float:
    """Get precomputed norm for an index."""
    _ensure_loaded()
    return _norms[idx]  # type: ignore[index]


def _zh_name(en: str) -> str:
    """Return Chinese name for an English ingredient, or empty string."""
    _ensure_loaded()
    return _zh_map.get(en, "")  # type: ignore[union-attr]


def _top_k_neighbors(query_vec: list[float], exclude: str | None = None,
                     k: int = 10) -> list[PairingResult]:
    """Find top-K nearest neighbors by cosine similarity."""
    _ensure_loaded()
    q_norm = _vec_norm(query_vec)

    scores: list[tuple[int, float]] = []
    for i, emb in enumerate(_embeddings):  # type: ignore[union-attr]
        if _itos[i] == exclude:  # type: ignore[index]
            continue
        sim = _cosine_sim(query_vec, emb, q_norm, _norms[i])  # type: ignore[index]
        scores.append((i, sim))

    scores.sort(key=lambda x: x[1], reverse=True)
    top = scores[:k]

    return [
        PairingResult(name=_itos[i], name_zh=_zh_name(_itos[i]), score=score)  # type: ignore[index]
        for i, score in top
    ]


def _mode_centroid(mode: dict) -> list[float]:
    """Compute centroid vector for a mode's members."""
    _ensure_loaded()
    members: list[str] = mode["members"]
    if not members:
        dim = len(_embeddings[0])  # type: ignore[index]
        return [0.0] * dim

    # Sum all member embeddings that exist in vocab
    dim = len(_embeddings[0])  # type: ignore[index]
    centroid = [0.0] * dim
    count = 0
    for name in members:
        if name in _vocab:  # type: ignore[operator]
            emb = _embeddings[_vocab[name]]  # type: ignore[index]
            for j in range(dim):
                centroid[j] += emb[j]
            count += 1

    if count > 0:
        centroid = [c / count for c in centroid]
    return centroid


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_pairings(ingredient: str, k: int = 10) -> list[PairingResult]:
    """Top-K nearest neighbors by cosine similarity.

    Input: English canonical name (e.g. "chicken").
    Returns self excluded.
    """
    _ensure_loaded()
    vec = _get_embedding(ingredient)
    return _top_k_neighbors(vec, exclude=ingredient, k=k)


def get_substitute(ingredient: str, k: int = 5) -> list[PairingResult]:
    """Same as get_pairings but default k=5, for substitution use case."""
    _ensure_loaded()
    vec = _get_embedding(ingredient)
    return _top_k_neighbors(vec, exclude=ingredient, k=k)


def slerp_explore(seed: str, direction: str, angle_deg: float = 30.0,
                  k: int = 10) -> list[PairingResult]:
    """SLERP rotation: rotate seed vector toward a direction.

    direction can be a cuisine key (e.g. "South_Asian") or an ingredient name.
    angle_deg: 0=seed unchanged, 60=heavily rotated toward target.

    Implementation: normalize seed, Gram-Schmidt orthogonalize direction,
    then q = cos(theta)*seed + sin(theta)*d_perp, find top-K neighbors of q.
    """
    _ensure_loaded()
    seed_vec = _get_embedding(seed)
    seed_unit = _normalize_vec(seed_vec)

    # Resolve direction vector
    poles = _metadata["cuisinePoles"]  # type: ignore[index]
    if direction in poles:
        dir_vec = poles[direction]
    elif direction in _vocab:  # type: ignore[operator]
        dir_vec = _get_embedding(direction)
    else:
        raise ValueError(
            f"Direction '{direction}' is not a cuisine key or ingredient name"
        )

    dir_unit = _normalize_vec(dir_vec)

    # Gram-Schmidt: d_perp = dir_unit - dot(dir_unit, seed_unit) * seed_unit
    proj = _dot(dir_unit, seed_unit)
    d_perp = [di - proj * si for di, si in zip(dir_unit, seed_unit)]
    d_perp_norm = _vec_norm(d_perp)
    if d_perp_norm < _NORM_EPS:
        # Direction is parallel to seed — return seed's neighbors
        return _top_k_neighbors(seed_vec, exclude=seed, k=k)
    d_perp = [x / d_perp_norm for x in d_perp]

    # Rotate: q = cos(theta)*seed_unit + sin(theta)*d_perp
    theta = math.radians(angle_deg)
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    q = [cos_t * si + sin_t * di for si, di in zip(seed_unit, d_perp)]

    return _top_k_neighbors(q, exclude=seed, k=k)


def get_mode(ingredient: str, k: int = 3) -> list[ModeResult]:
    """Find the k closest mode clusters for an ingredient."""
    _ensure_loaded()
    vec = _get_embedding(ingredient)
    vec_norm = _vec_norm(vec)

    modes = _metadata["modes"]  # type: ignore[index]
    scored: list[tuple[int, float]] = []

    for i, mode in enumerate(modes):
        centroid = _mode_centroid(mode)
        centroid_norm = _vec_norm(centroid)
        sim = _cosine_sim(vec, centroid, vec_norm, centroid_norm)
        scored.append((i, sim))

    scored.sort(key=lambda x: x[1], reverse=True)
    top = scored[:k]

    results: list[ModeResult] = []
    for idx, score in top:
        mode = modes[idx]
        # Build a mode_id from property + label
        mode_id_val = f"{mode['property']}/{mode['label']}"
        results.append(ModeResult(
            mode_id=mode_id_val,
            kind=mode["kind"],
            property=mode["property"],
            label=mode["label"],
            score=score,
            n_members=mode["n_members"],
            members=mode["members"][:20],
        ))

    return results


def search_ingredient(query: str, limit: int = 20) -> list[str]:
    """Search ingredient names. Supports:

    - English prefix match (e.g. "chi" -> chicken, chickpea, chive...)
    - Chinese reverse lookup via zh_map (e.g. "鸡肉" -> "chicken")

    Return English canonical names.
    """
    _ensure_loaded()
    results: list[str] = []
    seen: set[str] = set()
    q_lower = query.lower()

    # Chinese reverse lookup
    for en, zh in _zh_map.items():  # type: ignore[union-attr]
        if query in zh and en not in seen:
            results.append(en)
            seen.add(en)

    # English prefix match
    for name in _itos:  # type: ignore[union-attr]
        if name not in seen and name.lower().startswith(q_lower):
            results.append(name)
            seen.add(name)

    return results[:limit]


def get_cuisine_poles() -> dict[str, list[float]]:
    """Return all available cuisine direction poles."""
    _ensure_loaded()
    return dict(_metadata["cuisinePoles"])  # type: ignore[index]


def list_vocab() -> list[str]:
    """Return all 1,790 ingredient names."""
    _ensure_loaded()
    return list(_itos)  # type: ignore[arg-type]
