"""英文菜维度 → 中文维度映射（推荐接口预留）。

翻译完成后只需填充下方三个 dict，英文菜即进入推荐打分，无需改动
score_dish / recommend_dish / API /recommend 端点。

工作原理：API /recommend 返回的候选集里，中文菜 cuisine/method 已是中文
（原样穿过）；英文菜是 "italian"/"bake" 等英文值。score_dish 用
`dish.get("cuisine") in prefs["cuisine"]` 精确匹配 profile 里的中文 key，
英文值匹配不上只得基线 0.5。normalize_dish 在打分前把英文值查表替换成
中文词表中的值，英文菜才能被正确打分。

目标中文词表（value 必须落在此集合内）：
  cuisine: 东北/东南亚/京菜/客家/家常/川菜/日式/浙菜/湘菜/粤菜/苏菜/西北/西式/闽菜/韩式/鲁菜
  cooking_method: 凉拌/微波/炒/炖煮/烘焙/烤/煎炸/蒸/调味/饮品/其他

注：cook_time (quick/medium/long/very_long) 与 difficulty (1-5) 中英文已对齐，
无需映射。
"""

# 英文 cuisine → 中文 cuisine。
# key = 英文原值（与 KV index 里 cuisine 字段一致，小写）
# value = 上方目标中文 cuisine 词表中的值（一对多允许，如 italian/american/french → 西式）
CUISINE_ZH_MAP: dict[str, str] = {
    # 翻译完成后填充，例：
    # "italian": "西式",
    # "american": "西式",
    # "french": "西式",
    # "japanese": "日式",
    # "korean": "韩式",
    # "mexican": "西式",
    # "indian": "西式",
    # "mediterranean": "西式",
}

# 英文 cooking_method → 中文 cooking_method。
METHOD_ZH_MAP: dict[str, str] = {
    # "bake": "烘焙",
    # "roast": "烤",
    # "simmer": "炖煮",
    # "boil": "炖煮",
    # "deep-fry": "煎炸",
    # "broil": "烤",
    # "steam": "蒸",
    # "stir_fry": "炒",
}

# 英文 main_ingredients → 中文（可选，打分权重小 0.05）。
INGREDIENT_ZH_MAP: dict[str, str] = {}


def _map(value: str, table: dict[str, str]) -> str:
    """查表；命中返回映射值，未命中原样返回（中文菜不受影响）。"""
    if not value:
        return value
    return table.get(value, value)


def normalize_dish(dish: dict) -> dict:
    """把英文维度归一化到中文词表。推荐链路唯一挂载点。

    - cuisine/method/ingredients 命中映射 → 替换为中文值（score_dish 才认）
    - 未命中 → 保留原值（score_dish 用 in 精确匹配，未命中得基线 0.5，不报错）
    - difficulty/cook_time 已对齐，不动
    返回新 dict，不改原对象（遵循 immutability 规范）。
    """
    return {
        **dish,
        "cuisine": _map(dish.get("cuisine", ""), CUISINE_ZH_MAP),
        "cooking_method": _map(dish.get("cooking_method", ""), METHOD_ZH_MAP),
        "main_ingredients": [
            _map(i, INGREDIENT_ZH_MAP) for i in dish.get("main_ingredients", [])
        ],
    }
