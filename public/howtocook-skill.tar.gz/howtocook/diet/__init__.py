"""素食检测模块 — DietResult 定义 + 统一入口"""

from dataclasses import dataclass
from diet.auto_detect import detect_diet, DietLevel
from diet.overrides import load_overrides


@dataclass(frozen=True)
class DietResult:
    tags: list[str]        # ["素食"], ["蛋奶素"], 或 []
    level: DietLevel       # VEGAN / LACTO_OVO / NONE
    confidence: float      # 0.0-1.0
    source: str            # "auto" 或 "override"


def get_diet(name: str, ingredients: list[str], dish_id: str = "") -> DietResult:
    """统一素食检测入口。先查 override，无命中则自动检测。"""
    overrides = load_overrides()
    if dish_id and dish_id in overrides:
        entry = overrides[dish_id]
        return DietResult(
            tags=entry["tags"],
            level=DietLevel(entry["level"]),
            confidence=1.0,
            source="override",
        )

    result = detect_diet(name, ingredients)
    return DietResult(
        tags=result.tags,
        level=result.level,
        confidence=result.confidence,
        source="auto",
    )
