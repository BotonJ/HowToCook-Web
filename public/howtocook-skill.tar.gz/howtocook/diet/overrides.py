"""素食检测 override 读写 — 允许人工修正自动检测结果"""

import json
from pathlib import Path

OVERRIDES_PATH = Path(__file__).parent.parent / "diet_overrides.json"


def load_overrides() -> dict:
    """加载 override 数据。文件不存在则返回空 dict。"""
    if not OVERRIDES_PATH.exists():
        return {}
    with open(OVERRIDES_PATH, encoding="utf-8") as f:
        return json.load(f)


def save_overrides(data: dict) -> None:
    """持久化 override 数据。"""
    with open(OVERRIDES_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def set_override(dish_id: str, tags: list[str], level: str, reason: str = "") -> None:
    """设置单条 override。"""
    data = load_overrides()
    data[dish_id] = {
        "tags": tags,
        "level": level,
        "reason": reason,
    }
    save_overrides(data)


def remove_override(dish_id: str) -> bool:
    """删除单条 override。返回是否删除成功。"""
    data = load_overrides()
    if dish_id in data:
        del data[dish_id]
        save_overrides(data)
        return True
    return False


def list_overrides() -> dict:
    """列出所有 override。"""
    return load_overrides()
