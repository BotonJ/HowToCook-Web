"""改进版素食检测 — 减少假阳性/假阴性，区分蛋奶素 vs 纯素"""

from dataclasses import dataclass
from enum import Enum


class DietLevel(str, Enum):
    VEGAN = "vegan"            # 纯素：无任何动物制品
    LACTO_OVO = "lacto_ovo"   # 蛋奶素：允许蛋、奶
    NONE = "none"              # 非素食


@dataclass(frozen=True)
class AutoDetectResult:
    tags: list[str]
    level: DietLevel
    confidence: float


# ── 肉类关键词（补全遗漏） ─────────────────────────────────

_MEAT_KEYWORDS = [
    # 禽类
    "鸡", "鸭", "鹅", "鹌鹑", "鸽",
    # 畜类
    "猪", "牛", "羊", "鹿", "兔", "驴",
    # 肉制品
    "肉", "排骨", "肘子", "猪蹄", "蹄花", "五花肉", "里脊",
    "肉末", "肉糜", "肉馅", "肉丝", "肉片", "肉块", "肉丁",
    "培根", "火腿", "腊肉", "腊肠", "香肠", "午餐肉", "肉松",
    # 海鲜
    "鱼", "虾", "蟹", "鳝", "鳗", "鲍鱼", "海参", "生蚝",
    "蛏", "蛤", "鲈", "鲤", "鲢", "鳜", "翘嘴", "田螺",
    "小龙虾", "罗氏虾", "虾仁", "虾皮", "干虾", "虾米",
    "鱿鱼", "墨鱼", "章鱼", "带鱼", "鳕鱼", "三文鱼", "金枪鱼",
    "鲈鱼", "鲈鱼", "梭子蟹", "大闸蟹", "蛤蜊", "扇贝", "瑶柱",
    # 内脏（用多字词避免误匹配，如"黄心""猪肝"）
    "腰花", "大肠", "猪肝", "鸡肝", "鸭肝", "猪肚", "牛肚",
    "鸭血", "猪血", "鸡血",
    # 其他
    "鸡汤", "骨汤", "高汤", "肉汤", "虾皮",
]

# 调味/技法名中含肉类字但不含肉 — 排除误触发
_MEAT_NAME_EXCLUDES = [
    "鱼香",       # 川菜调味型，无鱼
    "蟹黄豆腐",   # 部分做法用咸蛋黄模拟
    "素鸡",       # 豆制品
    "素鸭",       # 豆制品
    "素鹅",       # 豆制品
    "素排骨",     # 蔬菜/面筋制品
    "素肉",       # 植物蛋白
    "素鱼",       # 豆制品
    "鱼露",       # 调味料
]

# 食材级排除（匹配后视为不含肉类）
_INGREDIENT_EXCLUDES = [
    "素鸡", "素鸭", "素鹅", "素排骨", "素肉", "素鱼",
    "肉桂", "肉豆蔻",
    "鸡粉", "鸡精",           # 调味料，非鸡肉
    "虾皮", "虾米", "干虾",   # 调味用量极少
]

# 蛋类关键词（匹配后视为蛋类而非肉类）
_EGG_KEYWORDS = [
    "鸡蛋", "蛋黄", "蛋白", "蛋液", "全蛋", "全蛋液",
    "咸蛋", "皮蛋", "松花蛋", "鹌鹑蛋", "鸭蛋",
]


def detect_diet(name: str, ingredients: list[str]) -> AutoDetectResult:
    """检测菜品素食类型。

    逻辑：
    1. 合并菜名+食材为文本
    2. 检查是否含肉类关键词（排除调味名误触发）
    3. 检查是否含蛋/奶
    4. 返回结果：
       - 无肉+无蛋奶 → 纯素 (vegan)
       - 无肉+有蛋奶 → 蛋奶素 (lacto_ovo)
       - 有肉 → 非素食 (none)
    """
    name_text = name
    ingredient_text = ",".join(ingredients)
    all_text = name_text + "," + ingredient_text

    # 检查肉类（菜名级排除）
    has_meat = _has_meat(name_text, ingredient_text, all_text)

    # 检查蛋奶
    has_egg_dairy = _has_egg_dairy(all_text)

    if has_meat:
        return AutoDetectResult(tags=[], level=DietLevel.NONE, confidence=0.9)

    if has_egg_dairy:
        return AutoDetectResult(tags=["蛋奶素"], level=DietLevel.LACTO_OVO, confidence=0.8)

    return AutoDetectResult(tags=["素食"], level=DietLevel.VEGAN, confidence=0.7)


def _has_meat(name: str, ingredient_text: str, all_text: str) -> bool:
    """检查是否含肉，排除调味名、素食仿制品和蛋类。"""
    # 菜名级排除
    for exc in _MEAT_NAME_EXCLUDES:
        if exc in name:
            name = name.replace(exc, "")

    check_text = name + "," + ingredient_text

    # 先去掉蛋类关键词，避免 "鸡蛋" 中的 "鸡" 触发肉类检测
    text_no_egg = check_text
    for egg_kw in _EGG_KEYWORDS:
        text_no_egg = text_no_egg.replace(egg_kw, "")

    for kw in _MEAT_KEYWORDS:
        if kw in text_no_egg:
            # 关键词级排除：检查匹配到的文本片段是否是排除词的一部分
            # 如匹配到 "鸡"，检查上下文是否是 "素鸡"/"鸡粉" 等
            kw_excluded = any(exc in text_no_egg for exc in _INGREDIENT_EXCLUDES if kw in exc)
            if not kw_excluded:
                return True

    return False


def _has_egg_dairy(text: str) -> bool:
    """检查是否含蛋或奶制品。"""
    egg_keywords = ["鸡蛋", "蛋黄", "蛋白", "蛋液", "全蛋", "咸蛋", "皮蛋", "松花蛋", "鹌鹑蛋"]
    dairy_keywords = ["牛奶", "奶油", "芝士", "奶酪", "黄油", "酸奶", "淡奶油", "炼乳", "奶粉"]

    for kw in egg_keywords + dairy_keywords:
        if kw in text:
            return True

    # 单独 "蛋" 需要排除"蛋白"质等误触发
    if "蛋" in text:
        # 排除：蛋白质、蛋白粉
        if "蛋白质" not in text and "蛋白粉" not in text:
            return True

    return False
