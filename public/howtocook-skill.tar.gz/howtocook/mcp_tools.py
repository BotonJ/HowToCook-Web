#!/usr/bin/env python3
"""HowToCook MCP Tools — HTTP API 封装，供 Claude Code / Hermes 等代理直接调用。"""

import json
import logging
import re
import urllib.parse
from typing import Any, Optional

from http_client import api_get, ApiError  # noqa: F401 — ApiError re-exported for callers/tests
from epicure.engine import search_ingredient as _search_epicure_ingredient

logger = logging.getLogger(__name__)

API_BASE = "https://api.howtocook.cn"  # kept for backward-compat imports
_TIMEOUT = 15
_MAX_RESPONSE_SIZE = 5 * 1024 * 1024  # 5 MB
_USER_AGENT = "howtocook-mcp/1.0"


def _api_get(path: str, params: dict[str, str] | None = None) -> dict[str, Any]:
    """GET JSON from the HowToCook API. Raises ApiError on failure.

    Thin wrapper over the shared :func:`http_client.api_get`, preserving the
    mcp_tools-specific constraints (5 MB cap, 15 s timeout, mcp user-agent).
    """
    return api_get(
        path,
        params=params,
        timeout=_TIMEOUT,
        max_response_size=_MAX_RESPONSE_SIZE,
        user_agent=_USER_AGENT,
    )


def search_recipes(
    q: str = "",
    category: str = "",
    cuisine: str = "",
    cooking_method: str = "",
    cook_time: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """搜索菜谱。返回 {results, total, query}。"""
    params: dict[str, str] = {}
    if q:
        params["q"] = q
    if category:
        params["category"] = category
    if cuisine:
        params["cuisine"] = cuisine
    if cooking_method:
        params["cooking_method"] = cooking_method
    if cook_time:
        params["cook_time"] = cook_time
    if limit != 20:
        params["limit"] = str(limit)
    return _api_get("/search", params)


def recommend_recipes(
    source: str = "",
    category: str = "",
    cuisine: str = "",
    cooking_method: str = "",
    cook_time: str = "",
    difficulty_max: int | None = None,
    language: str = "",
    limit: int = 200,
) -> dict[str, Any]:
    """推荐候选集。返回 {results: DishIndex[], total, query}。

    API 只做过滤，返回完整 DishIndex（含 tags/main_ingredients），供 skill
    用本地 profile 打分。difficulty_max 为 1-5 数值上界。
    """
    params: dict[str, str] = {}
    if source:
        params["source"] = source
    if category:
        params["category"] = category
    if cuisine:
        params["cuisine"] = cuisine
    if cooking_method:
        params["cooking_method"] = cooking_method
    if cook_time:
        params["cook_time"] = cook_time
    if difficulty_max is not None:
        params["difficulty_max"] = str(difficulty_max)
    if language:
        params["language"] = language
    if limit != 200:
        params["limit"] = str(limit)
    return _api_get("/recommend", params)


def get_recipe(recipe_id: str) -> dict[str, Any]:
    """获取菜谱详情。返回菜谱完整数据。"""
    if not recipe_id:
        raise ApiError("recipe_id 不能为空")
    # canonical id 形如 source/name，含 "/" 与可能的中文/特殊字符。
    # 校验格式并对路径段编码（保留 source/name 的 "/" 字面分隔），
    # 防止路径操纵与 URL 损坏。worker 端 safeDecode 兼容已编码形式。
    if not re.fullmatch(r"[^/]+/[^/]+", recipe_id):
        raise ApiError(f"recipe_id 格式应为 source/name: {recipe_id!r}")
    encoded = urllib.parse.quote(recipe_id, safe="/")
    return _api_get(f"/recipe/{encoded}")


def get_categories() -> dict[str, Any]:
    """获取分类列表。返回 {categories: [...]}。"""
    return _api_get("/categories")


def check_api_health() -> bool:
    """检查 API 是否可用。"""
    try:
        _api_get("/health")
        return True
    except ApiError:
        return False


# ── MCP tool entry points (structured JSON responses) ────────────────


def tool_search(q: str = "", **filters: str) -> str:
    """MCP tool: 搜索菜谱。返回 JSON 字符串。"""
    try:
        result = search_recipes(q=q, **filters)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_recipe(recipe_id: str) -> str:
    """MCP tool: 获取菜谱详情。返回 JSON 字符串。"""
    try:
        result = get_recipe(recipe_id)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_categories() -> str:
    """MCP tool: 获取分类列表。返回 JSON 字符串。"""
    try:
        result = get_categories()
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_recommend(
    source: str = "",
    category: str = "",
    cuisine: str = "",
    cooking_method: str = "",
    cook_time: str = "",
    difficulty_max: int | None = None,
    language: str = "",
    limit: int = 200,
) -> str:
    """MCP tool: 推荐菜谱候选集。返回 JSON 字符串。"""
    try:
        result = recommend_recipes(
            source=source,
            category=category,
            cuisine=cuisine,
            cooking_method=cooking_method,
            cook_time=cook_time,
            difficulty_max=difficulty_max,
            language=language,
            limit=limit,
        )
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


# ── Epicure ingredient intelligence ──────────────────────────────────


def _resolve_ingredient_name(query: str) -> str:
    """把中文/模糊食材名解析成 Epicure API 认识的英文 canonical name。

    优先用本地 ``epicure.engine.search_ingredient`` 做中文反向映射和英文前缀
    匹配；解析失败时原样返回（让 API 返回 404）。
    """
    if not query or not query.strip():
        raise ApiError("食材名称不能为空")
    query = query.strip()
    try:
        candidates = _search_epicure_ingredient(query, limit=1)
        if candidates:
            return candidates[0]
    except Exception:
        # 本地数据缺失时回退到原字符串，由 API 决定
        pass
    return query.lower().replace(" ", "_")


def get_pairings(ingredient: str, k: int = 10) -> dict[str, Any]:
    """食材配对。返回 API 的 {results, query, total}。"""
    params = {"q": ingredient}
    if k != 10:
        params["k"] = str(k)
    return _api_get("/epicure/pair", params)


def get_substitutes(ingredient: str, k: int = 5) -> dict[str, Any]:
    """食材替代。返回 API 的 {results, query, total}。"""
    params = {"q": ingredient}
    if k != 5:
        params["k"] = str(k)
    return _api_get("/epicure/substitute", params)


def explore_ingredient(
    seed: str, direction: str, angle: float = 30.0, k: int = 10
) -> dict[str, Any]:
    """风味探索（SLERP）。返回 API 的 {results, query, total}。"""
    params = {
        "seed": seed,
        "dir": direction,
        "angle": str(angle),
    }
    if k != 10:
        params["k"] = str(k)
    return _api_get("/epicure/explore", params)


def get_ingredient_mode(ingredient: str, k: int = 3) -> dict[str, Any]:
    """烹饪群落。返回 API 的 {results, query, total}。"""
    params = {"q": ingredient}
    if k != 3:
        params["k"] = str(k)
    return _api_get("/epicure/mode", params)


def search_ingredients(q: str, limit: int = 20) -> dict[str, Any]:
    """食材名搜索。返回 API 的 {results, query, total}。"""
    params = {"q": q}
    if limit != 20:
        params["limit"] = str(limit)
    return _api_get("/epicure/search", params)


def get_ingredient_vocab() -> dict[str, Any]:
    """获取全部食材词表。返回 API 的 {ingredients, total}。"""
    return _api_get("/epicure/vocab")


def get_ingredient_cuisines() -> dict[str, Any]:
    """获取全部风味方向。返回 API 的 {cuisines, total}。"""
    return _api_get("/epicure/cuisines")


# ── MCP tool entry points for Epicure ────────────────────────────────


def tool_pair(ingredient: str, k: int = 10) -> str:
    """MCP tool: 食材配对（什么和 X 搭配）。返回 JSON 字符串。"""
    try:
        name = _resolve_ingredient_name(ingredient)
        result = get_pairings(name, k=k)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_substitute(ingredient: str, k: int = 5) -> str:
    """MCP tool: 食材替代（没有 X 用什么替代）。返回 JSON 字符串。"""
    try:
        name = _resolve_ingredient_name(ingredient)
        result = get_substitutes(name, k=k)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_explore(seed: str, direction: str, angle: float = 30.0, k: int = 10) -> str:
    """MCP tool: 风味探索（把 X 往某菜系方向旋转）。返回 JSON 字符串。"""
    try:
        seed_name = _resolve_ingredient_name(seed)
        result = explore_ingredient(seed_name, direction, angle=angle, k=k)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_mode(ingredient: str, k: int = 3) -> str:
    """MCP tool: 烹饪群落（X 属于什么风味群）。返回 JSON 字符串。"""
    try:
        name = _resolve_ingredient_name(ingredient)
        result = get_ingredient_mode(name, k=k)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_search_ingredient(q: str, limit: int = 20) -> str:
    """MCP tool: 搜索食材名（英文前缀 / 中文反向查找）。返回 JSON 字符串。"""
    try:
        name = _resolve_ingredient_name(q)
        result = search_ingredients(name, limit=limit)
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_epicure_vocab() -> str:
    """MCP tool: 列出 Epicure 支持的全部食材。返回 JSON 字符串。"""
    try:
        result = get_ingredient_vocab()
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


def tool_epicure_cuisines() -> str:
    """MCP tool: 列出 Epicure 支持的风味方向。返回 JSON 字符串。"""
    try:
        result = get_ingredient_cuisines()
        return json.dumps(result, ensure_ascii=False)
    except ApiError as exc:
        return json.dumps({"error": str(exc)}, ensure_ascii=False)


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    if len(sys.argv) < 2:
        print("用法:")
        print("  python mcp_tools.py search <关键词>")
        print("  python mcp_tools.py recipe <id>")
        print("  python mcp_tools.py categories")
        print("  python mcp_tools.py health")
        print("  python mcp_tools.py pair <食材> [k]")
        print("  python mcp_tools.py substitute <食材> [k]")
        print("  python mcp_tools.py explore <食材> <方向> [angle] [k]")
        print("  python mcp_tools.py mode <食材> [k]")
        print("  python mcp_tools.py search-ingredient <关键词> [limit]")
        print("  python mcp_tools.py vocab")
        print("  python mcp_tools.py cuisines")
        sys.exit(1)

    cmd = sys.argv[1]

    def _int_arg(idx: int, default: int) -> int:
        try:
            return int(sys.argv[idx]) if len(sys.argv) > idx else default
        except ValueError:
            return default

    def _float_arg(idx: int, default: float) -> float:
        try:
            return float(sys.argv[idx]) if len(sys.argv) > idx else default
        except ValueError:
            return default

    if cmd == "search":
        q = sys.argv[2] if len(sys.argv) > 2 else ""
        print(tool_search(q))
    elif cmd == "recipe":
        if len(sys.argv) < 3:
            print("缺少 recipe id", file=sys.stderr)
            sys.exit(1)
        print(tool_recipe(sys.argv[2]))
    elif cmd == "categories":
        print(tool_categories())
    elif cmd == "health":
        ok = check_api_health()
        print(json.dumps({"healthy": ok}))
    elif cmd == "pair":
        if len(sys.argv) < 3:
            print("缺少食材", file=sys.stderr)
            sys.exit(1)
        print(tool_pair(sys.argv[2], k=_int_arg(3, 10)))
    elif cmd == "substitute":
        if len(sys.argv) < 3:
            print("缺少食材", file=sys.stderr)
            sys.exit(1)
        print(tool_substitute(sys.argv[2], k=_int_arg(3, 5)))
    elif cmd == "explore":
        if len(sys.argv) < 4:
            print("缺少食材或方向", file=sys.stderr)
            sys.exit(1)
        print(
            tool_explore(
                sys.argv[2],
                sys.argv[3],
                angle=_float_arg(4, 30.0),
                k=_int_arg(5, 10),
            )
        )
    elif cmd == "mode":
        if len(sys.argv) < 3:
            print("缺少食材", file=sys.stderr)
            sys.exit(1)
        print(tool_mode(sys.argv[2], k=_int_arg(3, 3)))
    elif cmd == "search-ingredient":
        q = sys.argv[2] if len(sys.argv) > 2 else ""
        print(tool_search_ingredient(q, limit=_int_arg(3, 20)))
    elif cmd == "vocab":
        print(tool_epicure_vocab())
    elif cmd == "cuisines":
        print(tool_epicure_cuisines())
    else:
        print(f"未知命令: {cmd}", file=sys.stderr)
        sys.exit(1)
